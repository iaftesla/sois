#include <iostream>
#include <fstream>
#include <iomanip>
#include <regex>
#include <vector>
#include <string>
#include <algorithm>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <csv_file>\n";
        return 1;
    }
    std::ifstream infile(argv[1]);
    if (!infile) {
        std::cerr << "Cannot open file\n";
        return 1;
    }

    std::vector<std::vector<std::string>> table;
    const std::regex csv_regex(R"((?:\"([^\"]*)\"|([^,]+)|())(?:,|$))");
    std::string line;
    while (std::getline(infile, line)) {
        std::vector<std::string> row;
        std::smatch m;
        auto it = line.cbegin();
        while (it != line.cend()) {
            if (std::regex_search(it, line.cend(), m, csv_regex)) {
                std::string field;
                if (m[1].matched) field = m[1].str();
                else if (m[2].matched) field = m[2].str();
                else field = ""; // empty field
                row.push_back(field);
                it = m.suffix().first;
            }
        }
        table.push_back(row);
    }

    // Compute column widths
    std::vector<size_t> widths;
    for (const auto& row : table) {
        if (row.size() > widths.size()) widths.resize(row.size(), 0);
        for (size_t i = 0; i < row.size(); ++i) {
            widths[i] = std::max(widths[i], row[i].size());
        }
    }

    // Print table
    for (const auto& row : table) {
        for (size_t i = 0; i < row.size(); ++i) {
            std::cout << std::left << std::setw(widths[i] + 2) << row[i];
        }
        std::cout << '\n';
    }
    return 0;
}
