#include <iostream>
#include <vector>
#include <string>

std::vector<int> buildPrefix(const std::string& pattern) {
    int n = pattern.size();
    std::vector<int> pi(n, 0);
    for (int i = 1; i < n; ++i) {
        int j = pi[i - 1];
        while (j > 0 && pattern[i] != pattern[j])
            j = pi[j - 1];
        if (pattern[i] == pattern[j])
            ++j;
        pi[i] = j;
    }
    return pi;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <pattern> <text>\n";
        return 1;
    }

    const std::string pattern = argv[1];
    const std::string text = argv[2];
    const int n = pattern.size();

    std::vector<int> pi = buildPrefix(pattern);
    std::vector<bool> output(text.size(), false);
    int j = 0;

    for (size_t i = 0; i < text.size(); ++i) {
        while (j > 0 && text[i] != pattern[j])
            j = pi[j - 1];
        if (text[i] == pattern[j])
            ++j;
        if (j == n) {
            output[i] = true;
            j = pi[j - 1];
        }
    }

    for (bool b : output)
        std::cout << (b ? "true" : "false") << ' ';
    std::cout << '\n';
    return 0;
}
